"use client";

import React, { useEffect, useState } from "react";
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from "firebase/storage";
import { auth } from "@/lib/firebase";
import {
  signInWithCredential,
  GoogleAuthProvider,
  onAuthStateChanged,
} from "firebase/auth";
import { useSession } from "next-auth/react";

interface FileUploadProps {
  onImageUpload: (url: string) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onImageUpload }) => {
  const { data: session } = useSession();
  const [ready, setReady] = useState(false);
  const [uploading, setUploading] = useState(false);

  // ✅ Handle Firebase Auth once session is ready
  useEffect(() => {
    const initFirebaseAuth = async () => {
      if (!auth.currentUser && session?.idToken) {
        try {
          const credential = GoogleAuthProvider.credential(session.idToken);
          await signInWithCredential(auth, credential);
          console.log("🔐 Firebase signed in");
        } catch (error) {
          console.error("❌ Firebase auth error", error);
        }
      }
    };

    initFirebaseAuth();

    // ✅ Persistent Firebase Auth state listener
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        console.log("👤 Firebase user is ready");
        setReady(true);
      } else {
        setReady(false);
      }
    });

    // ✅ Clean up the listener on unmount
    return () => unsubscribe();
  }, [session?.idToken]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !ready || !auth.currentUser) return;

    try {
      setUploading(true);
      const storage = getStorage();
      const timestamp = Date.now();
      const safeFileName = `${timestamp}-${file.name.replace(/\s+/g, "-")}`;
      const fileRef = ref(
        storage,
        `user_uploads/${auth.currentUser.uid}/${safeFileName}`
      );

      await uploadBytes(fileRef, file);
      const url = await getDownloadURL(fileRef);

      console.log("✅ File uploaded to Firebase Storage:", url);
      onImageUpload(url);
    } catch (err) {
      console.error("❌ Upload failed:", err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mt-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Upload Image or File
      </label>
      <input type="file" onChange={handleFileChange} />
      {uploading && (
        <p className="text-sm text-gray-500 mt-2">Uploading file...</p>
      )}
    </div>
  );
};

export default FileUpload;
