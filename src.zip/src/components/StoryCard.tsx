"use client";

import { useRouter } from "next/navigation";
import { motion } from "framer-motion";

interface Story {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
}

interface StoryCardProps {
  story: Story;
  onDelete: (id: string) => void;
}

export default function StoryCard({ story, onDelete }: StoryCardProps) {
  const router = useRouter();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="border rounded-lg p-4 shadow hover:shadow-lg transition"
    >
      {story.imageUrl && (
        <img
          src={story.imageUrl}
          alt="Story Image"
          className="w-full h-48 object-cover rounded mb-4"
        />
      )}
      <h2 className="text-xl font-semibold mb-2">{story.title}</h2>
      <p className="text-gray-600 mb-4">{story.content.substring(0, 100)}...</p>
      <div className="flex gap-2">
        <button
          onClick={() => router.push(`/write/${story.id}`)}
          className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition"
        >
          Edit
        </button>
        <button
          onClick={() => onDelete(story.id)}
          className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition"
        >
          Delete
        </button>
      </div>
    </motion.div>
  );
}
