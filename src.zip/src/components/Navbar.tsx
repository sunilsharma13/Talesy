"use client";

import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Navbar() {
  const { data: session } = useSession();
  const router = useRouter();

  if (!session?.user) return null; // No Navbar on login

  return (
    <nav className="bg-blue-600 text-white p-4 shadow-md flex justify-between items-center">
      <Link href="/dashboard" className="text-xl font-bold hover:underline">
        Writing Platform
      </Link>

      <div className="flex items-center space-x-4">
        <span className="hidden sm:inline">{session.user.name}</span>

        <button
          onClick={() => router.push("/write/new")}
          className="bg-white text-blue-600 font-semibold px-4 py-2 rounded hover:bg-gray-100 transition"
        >
          Write
        </button>

        <button
          onClick={() =>
            signOut({
              callbackUrl: "/login", // 👈 REDIRECTS to Login after logout
            })
          }
          className="bg-white hover:bg-gray-100 text-blue-600 font-semibold px-4 py-2 rounded transition"
        >
          Logout
        </button>
      </div>
    </nav>
  );
}
