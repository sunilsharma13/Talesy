import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";
import { setLogLevel } from "firebase/firestore";

setLogLevel("debug");

const firebaseConfig = {
  apiKey: "AIzaSyD0iPxDfyIyp_dCYQVF07KAFKpPqGf1gAA",
  authDomain: "awesome-writing-page.firebaseapp.com",
  projectId: "awesome-writing-page",
  storageBucket: "awesome-writing-page.firebasestorage.app",
  messagingSenderId: "1085865855640",
  appId: "1:1085865855640:web:7f00bebf3dc76c202f9eed",
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);
const auth = getAuth(app);

export { db, storage, auth, app };
