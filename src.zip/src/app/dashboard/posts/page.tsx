// app/dashboard/posts/page.tsx

"use client";

import React, { useEffect, useState } from "react";
import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

interface Post {
  id: string;
  title: string;
  content: string;
  imageUrl: string;
}

const MyPostsPage = () => {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === "loading") return; // still verifying session

    if (status === "unauthenticated") {
      router.push("/login"); // redirect to login page
      return;
    }

    const fetchPosts = async () => {
      if (!session?.user?.email) return;

      try {
        const q = query(
          collection(db, "posts"),
          where("userId", "==", session.user.email)
        );

        const snapshot = await getDocs(q);
        const userPosts = snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            title: data.title,
            content: data.content,
            imageUrl: data.imageUrl,
          };
        });

        setPosts(userPosts);
      } catch (error) {
        console.error("Error fetching posts:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, [session, status, router]);

  if (status === "loading" || loading) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <p>Loading your posts...</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">📝 My Posts</h1>
      {posts.length === 0 ? (
        <p>No posts yet.</p>
      ) : (
        <div className="grid gap-6">
          {posts.map((post) => (
            <div key={post.id} className="border p-4 rounded-lg shadow">
              {post.imageUrl && (
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-60 object-cover rounded mb-4"
                />
              )}
              <h2 className="text-xl font-bold mb-2">{post.title}</h2>
              <p className="text-gray-600">
                {post.content.slice(0, 100)}...
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyPostsPage;
