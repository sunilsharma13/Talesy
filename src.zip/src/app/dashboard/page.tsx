"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, deleteDoc, doc, DocumentData } from "firebase/firestore";
import { useRouter } from "next/navigation";
import StoryCard from "@/components/StoryCard";

interface Story extends DocumentData {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
}

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStories = async () => {
      if (!session?.user?.email) return;
  
      const q = query(
        collection(db, "writings"),
        where("userId", "==", session.user.email)
      );
  
      const querySnapshot = await getDocs(q);
  
      const fetchedStories = querySnapshot.docs.map((docSnap) => {
        const data = docSnap.data() as Story;
        return {
          id: docSnap.id,
          title: data.title,
          content: data.content,
          imageUrl: data.imageUrl || "", 
        };
      });
  
      setStories(fetchedStories);
      setLoading(false);
    };
  
    fetchStories();
  }, [session]);
  
  const handleDelete = async (id: string) => {
    const confirmDelete = confirm("Are you sure you want to delete this story?");
    if (!confirmDelete) return;

    await deleteDoc(doc(db, "writings", id));
    setStories((prev) => prev.filter((story) => story.id !== id));
  };

  if (status === "loading") {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!session) {
    router.push("/login");
    return null;
  }

  return (
    <div className="max-w-5xl mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Your Writings</h1>
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
          onClick={() => router.push("/write")}
        >
          New Story
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Array.from({ length: 4 }).map((_, index) => (
            <SkeletonLoader key={index} />
          ))}
        </div>
      ) : stories.length === 0 ? (
        <div className="text-center text-gray-500">No stories found. Start writing!</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {stories.map((story) => (
            <StoryCard key={story.id} story={story} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
}

// ✨ SkeletonLoader Component
const SkeletonLoader = () => {
  return (
    <div className="border rounded-lg p-4 shadow animate-pulse space-y-4">
      <div className="bg-gray-300 h-48 w-full rounded"></div>
      <div className="h-6 bg-gray-300 rounded w-3/4"></div>
      <div className="h-4 bg-gray-300 rounded w-full"></div>
      <div className="h-4 bg-gray-300 rounded w-5/6"></div>
      <div className="flex gap-2 mt-4">
        <div className="h-8 w-20 bg-gray-300 rounded"></div>
        <div className="h-8 w-20 bg-gray-300 rounded"></div>
      </div>
    </div>
  );
};
