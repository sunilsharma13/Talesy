"use client";

import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import Image from "next/image";

export default function LoginPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (session) {
      router.push("/dashboard");
    }
  }, [session, router]);

  if (status === "loading") {
    return (
      <div className="flex justify-center items-center h-screen w-screen bg-gray-100">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen bg-gray-100">
      {/* Left Side */}
      <div className="flex flex-col justify-center items-start w-1/2 p-10 space-y-6">
        <h1 className="text-5xl font-extrabold text-blue-600 animate-pulse">
          Write what matters
        </h1>
        <p className="text-2xl text-gray-700 animate-bounce">
          I'll love your effort in writing.
        </p>
        <button
          onClick={() => signIn("google")}
          className="mt-6 bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded transition"
        >
          Login with Google
        </button>
      </div>

      {/* Right Side */}
      <div className="flex justify-center items-center w-1/2 p-10">
        <Image
          src="/login_image.jpg"
          alt="Login Illustration"
          width={500}
          height={500}
          className="object-contain"
        />
      </div>
    </div>
  );
}
