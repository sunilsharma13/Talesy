import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css"; // ✅ Make sure exact path hai
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SessionProvider from "@/components/SessionProvider";
import AuthRedirect from "@/components/AuthRedirect";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "My Writing Platform",
  description: "A place where everyone can write and share their thoughts.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="antialiased bg-gray-100 text-gray-900">
        <SessionProvider>
          <AuthRedirect />
          <Navbar />
          <main className="container mx-auto p-4">
            {/* TEST DIV */}
            <div className="text-4xl font-extrabold text-pink-500 bg-black p-5 rounded-lg">
              Hello, Tailwind is working!
            </div>

            {children}
          </main>
          <Footer />
        </SessionProvider>
      </body>
    </html>
  );
}
