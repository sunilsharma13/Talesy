"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { db } from "@/lib/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { useSession } from "next-auth/react";
import FileUpload from "@/components/FileUpload";

export default function WritePage() {
  const params = useParams();
  const id = params?.id as string | undefined;
  const router = useRouter();
  const { data: session } = useSession();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchWriting = async () => {
      if (!id || !session?.user?.email) return;

      const docRef = doc(db, "writings", id);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.userId !== session.user.email) {
          alert("You are not authorized to access this story.");
          router.push("/dashboard");
          return;
        }

        setTitle(data.title || "Untitled");
        setContent(data.content || "");
        if (data.imageUrl) setImageUrl(data.imageUrl);
      } else {
        alert("Story not found.");
        router.push("/dashboard");
      }
    };

    fetchWriting();
  }, [id, session, router]);

  const saveContent = async () => {
    if (!session?.user?.email) {
      console.error("❌ User session is invalid");
      return;
    }

    if (!title || !content) {
      console.error("❌ Title or content is missing");
      return;
    }

    try {
      setSaving(true);
      const docRef = doc(db, "writings", id!);

      console.log("🚀 Saving document with:");
      console.log("📝 Title:", title);
      console.log("🖊️ Content:", content);
      console.log("🖼️ Image URL:", imageUrl);

      await updateDoc(docRef, {
        title,
        content,
        imageUrl: imageUrl || "",
      });

      console.log("✅ Firestore document updated");
      router.push("/dashboard");
    } catch (err) {
      console.error("❌ Error updating Firestore:", err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full text-2xl font-bold mb-2 border p-2"
        placeholder="Title"
      />
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="w-full h-64 border p-2"
        placeholder="Start writing..."
      />

      <FileUpload
        onImageUpload={(url) => {
          console.log("📥 Image URL received:", url);
          setImageUrl(url);
        }}
      />

      {imageUrl && (
        <div className="mt-4">
          <p className="text-sm text-gray-500">Image Preview:</p>
          <img
            src={imageUrl}
            alt="Uploaded"
            className="w-32 h-32 object-cover mt-2"
          />
        </div>
      )}

      <button
        onClick={saveContent}
        disabled={saving}
        className="mt-4 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition"
      >
        {saving ? "Saving..." : "Save Story"}
      </button>
    </div>
  );
}
